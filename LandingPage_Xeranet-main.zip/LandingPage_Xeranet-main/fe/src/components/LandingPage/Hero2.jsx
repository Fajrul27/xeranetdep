import { motion } from "framer-motion";
import { FaShieldAlt, FaCode, FaNetworkWired } from "react-icons/fa";

const cardVariant = {
  hidden: { opacity: 0, y: 40 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.3,
      duration: 0.8,
      ease: "easeOut",
    },
  }),
};

const WhyUs = () => {
  return (
    <section className="bg-gradient-to-b from-black via-red-900 to-black text-white px-6 md:px-10 py-32">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-6 tracking-tight">
            Mengapa Kami ?
          </h1>
          <p className="text-gray-300 text-lg max-w-xl mx-auto">
            Kami bukan hanya penyedia layanan,   kami adalah mitra transformasi digital Anda. 
            Dengan teknologi mutakhir dan pendekatan strategis, kami hadir untuk membuat Anda unggul.
          </p>
        </motion.div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
          {/* Keamanan Tingkat Tinggi */}
          <motion.div
            custom={0}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={cardVariant}
            className="bg-[#1a1a1a]/80 backdrop-blur-md p-8 rounded-3xl shadow-xl hover:shadow-red-500/50 transition duration-300 transform hover:scale-105 group"
          >
            <div className="flex items-center gap-4 mb-6">
              <FaShieldAlt className="text-red-500 text-4xl" />
              <h2 className="text-2xl font-semibold text-white">Keamanan Tingkat Tinggi</h2>
            </div>
            <p className="text-gray-300 leading-relaxed text-base">
              Sistem keamanan berlapis, monitoring 24/7, dan layanan{" "}
              <span className="text-gold-400 font-medium">penetration testing</span> untuk menjaga aset Anda tetap aman.
            </p>
          </motion.div>

          {/* Pengembangan Kustom & Scalable */}
          <motion.div
            custom={1}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={cardVariant}
            className="bg-[#1a1a1a]/80 backdrop-blur-md p-8 rounded-3xl shadow-xl hover:shadow-red-500/50 transition duration-300 transform hover:scale-105 group"
          >
            <div className="flex items-center gap-4 mb-6">
              <FaCode className="text-gold-400 text-4xl" />
              <h2 className="text-2xl font-semibold text-white">Solusi Software Kustom</h2>
            </div>
            <p className="text-gray-300 leading-relaxed text-base">
              Platform digital yang dibangun sesuai kebutuhan bisnis Anda  skalabel, efisien, dan terintegrasi penuh.
            </p>
          </motion.div>

          {/* Infrastruktur & Dukungan Jaringan */}
          <motion.div
            custom={2}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={cardVariant}
            className="bg-[#1a1a1a]/80 backdrop-blur-md p-8 rounded-3xl shadow-xl hover:shadow-red-500/50 transition duration-300 transform hover:scale-105 group"
          >
            <div className="flex items-center gap-4 mb-6">
              <FaNetworkWired className="text-white text-4xl" />
              <h2 className="text-2xl font-semibold text-white">Jaringan & Infrastruktur</h2>
            </div>
            <p className="text-gray-300 leading-relaxed text-base">
              Arsitektur jaringan modern yang menjamin uptime, kecepatan, dan keamanan optimal untuk bisnis anda
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default WhyUs;
