import React, { useState, useEffect, useRef } from "react";
import logo from "./assets/logo.png"; // Pastikan logo ini ada dan valid
import { FaFacebook, FaTwitter, FaInstagram, FaTimes } from "react-icons/fa";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [userIP, setUserIP] = useState("Loading...");
  const menuRef = useRef(null);

  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    fetch("https://api64.ipify.org?format=json")
      .then((res) => res.json())
      .then((data) => setUserIP(data.ip))
      .catch(() => setUserIP("Unavailable"));
  }, []);

  useEffect(() => {
    const handleOutsideClick = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener("mousedown", handleOutsideClick);
    } else {
      document.removeEventListener("mousedown", handleOutsideClick);
    }

    return () => document.removeEventListener("mousedown", handleOutsideClick);
  }, [isOpen]);

  const toggleMenu = () => setIsOpen((prev) => !prev);

  const timeStr = currentTime.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });

  return (
    <>
      <nav className="navbar">
        <div className="navbar-container">
          <a href="/" className="logo-link">
            <img
              src={logo || "path/to/default-logo.png"} // Fallback jika logo tidak ditemukan
              alt="Logo"
              className="logo"
            />
          </a>
          <button className="menu-btn" onClick={toggleMenu} aria-label="Open Menu">
            ≡
          </button>
        </div>
      </nav>

      <div className={`menu-overlay ${isOpen ? "show" : ""}`}>
        <aside
          className={`menu-panel ${isOpen ? "slide-in" : "slide-out"}`}
          ref={menuRef}
        >
          <button className="close-btn" onClick={toggleMenu} aria-label="Close Menu">
            <FaTimes />
          </button>

          <div className="menu-header">
            <p className="current-time">{timeStr}</p>
            <p className="user-ip">IP: {userIP}</p>
          </div>

              <ul className="menu-links">
              <li><a href="/"><span>Home</span><span className="plus">+</span></a></li>
              <li><a href="/about"><span>About</span><span className="plus">+</span></a></li>
              <li><a href="/service"><span>Services</span><span className="plus">+</span></a></li>
              <li><a href="/blog"><span>Bloger</span><span className="plus">+</span></a></li>
              <li><a href="#"><span>Contac</span><span className="plus">+</span></a></li>
              <li><a href="/#"><span>Investor</span><span className="plus">+</span></a></li>
              <li><a href="/#"><span>mitra</span><span className="plus">+</span></a></li>
            </ul>

          <div className="menu-footer">
            <div className="social-links">
              <img
                src={logo || "path/to/default-logo.png"} // Fallback jika logo tidak ditemukan
                alt="Footer Logo"
                className="social-logo"
              />
              <div className="icons">
                <a href="#"><FaFacebook /></a>
                <a href="#"><FaTwitter /></a>
                <a href="#"><FaInstagram /></a>
              </div>
            </div>
          </div>
        </aside>
      </div>

      {/* Perbaikan di sini: Menghapus 'jsx' dari style */}
      <style>{`
        .navbar {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          background: #000;
          backdrop-filter: blur(8px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
          z-index: 1000;
          padding: 10px 0;
        }

        .navbar-container {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 50px;
          position: relative;
        }

        .logo-link {
          display: flex;
          align-items: center;
        }

        .logo {
          height: 35px; /* Logo lebih kecil */
        }

        .menu-btn {
          padding: 0 50px;
          position: fixed;
          right: 10px;
          top: 50%;
          transform: translateY(-50%);
          font-size: 2.5rem;
          background: none;
          border: none;
          color: white;
          cursor: pointer;
        }

        .menu-overlay {
          position: fixed;
          top: 0;
          right: 0;
          bottom: 0;
          left: 0;
          background: rgba(0, 0, 0, 0.6);
           backdrop-filter: blur(5px);
          z-index: 1001;
          pointer-events: ${isOpen ? "auto" : "none"};
          transition: opacity 0.3s ease;
          opacity: ${isOpen ? 1 : 0};
        }

        .menu-panel {
          position: fixed;
          top: 0px;
          right: 0;
          width: 500px;
          height: 100vh;
          backdrop-filter: blur(10px);
          background:  rgba(100, 99, 99, 0.2);
          color: white;
          padding-left: 40px;
          padding: 20px;
          display: flex;
          flex-direction: column;
          overflow-y: auto;
        }

        .menu-links {
          list-style: none;
          padding-left: 30px;
          margin: 50px 0 30px 0;
        }

        .menu-footer {
          margin-top: 10px;
          padding-top: 20px;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .slide-in {
          transform: translateX(0%);
        }

        .slide-out {
          transform: translateX(100%);
        }

        .close-btn {
          position: absolute;
          top: 30px;
          right: 30px;
          background: none;
          border: none;
          color: grey;
          font-size: 1.8rem;
          cursor: pointer;
        }

        .menu-header {
          text-align: left;
          margin-bottom: 20px;
          margin-top: 60px;
        }

        .current-time {
        padding-left: 50px;
          font-size: 2rem;
          font-weight: bold;
        }

        .user-ip {
        padding-left: 50px;
          font-size: 1rem;
          color: #ccc;
        }

        .menu-links li {
          padding: 12px 0;
          border-bottom: 1px solid rgba(74, 74, 74, 0.57);
          width: 88%;
          margin: 0 auto;
        }

       .menu-links a {
       
  color: white;
  text-decoration: none;
  font-size: 1.2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.plus {
  font-weight: bold;
  font-size: 1.4rem;
}

        .menu-links a:hover {
          color: red;
        }

        .social-links {
       padding-left: 50px;
          margin-top: 3px;
          text-align: left;
        }

        .social-logo {
          height: 25px;
          margin-bottom: 7px;
        }

        .icons {
          display: flex;
          align-items: center;
          margin-top: 10px;
        }

        .icons a {
        
          font-size: 1.4rem;
          padding: 10px;
          color: white;
          margin-right: 15px;
        }

        .icons a:last-child {
          margin-right: 0;
        }

        .icons a:hover {
          color: red;
        }

        @media (max-width: 768px) {
          .navbar-container {
            padding: 0 20px;
          }

          .logo {
          padding-left: 50px;
            height: 28px;
          }

          .menu-btn {
            padding: 0 20px;
            font-size: 2rem;
            right: 15px;
          }

          .menu-panel {
            width: 75vw;
            top: 0;
            height: 100vh;
            padding: 20px 16px;
          }

          .close-btn {
            top: 15px;
            right: 15px;
          }

          .menu-header {
            margin-top: 50px;
          }

          .menu-links li {
            width: 100%;
          }

          .menu-footer {
            padding-bottom: 20px;
          }

          .icons a {
            font-size: 1.2rem;
            padding: 8px;
          }
        }

        @media (max-width: 480px) {
          .logo {
            height: 24px;
          }

          .menu-btn {
            font-size: 1.8rem;
          }

          .current-time {
            font-size: 1.4rem;
          }

          .user-ip {
            font-size: 0.9rem;
          }

          .menu-links a {
            font-size: 1rem;
          }

          .icons a {
            padding-left: 40px;
            font-size: 1rem;
            padding: 6px;
          }

          .social-logo {
            height: 20px;
          }
        }
      `}</style>
    </>
  );
};

export default Navbar;
