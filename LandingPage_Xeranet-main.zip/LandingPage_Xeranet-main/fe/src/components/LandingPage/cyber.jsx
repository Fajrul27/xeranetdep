import { motion } from 'framer-motion';
import { FaShieldAlt, FaNetworkWired, FaSearch, FaUserSecret, FaLaptopCode } from 'react-icons/fa';

const services = [
  {
    icon: <FaSearch />,
    title: "Vulnerability Assessment & Penetration Testing",
    desc: "Uji keamanan sistem Anda dengan pendekatan ofensif untuk menemukan dan memperbaiki celah sebelum dimanfaatkan oleh penyerang. Layanan ini sangat penting untuk organisasi yang mengelola data sensitif atau layanan digital publik.",
  },
  {
    icon: <FaShieldAlt />,
    title: "Managed SOC & Threat Monitoring",
    desc: "Tim Security Operations Center (SOC) kami bekerja 24/7 untuk memantau, mendeteksi, dan merespon setiap aktivitas mencurigakan secara real-time. Solusi ini memastikan Anda tidak perlu khawatir terhadap serangan mendadak yang sulit dideteksi manual.",
  },
  {
    icon: <FaNetworkWired />,
    title: "Network Security & Firewall Hardening",
    desc: "Kami bantu Anda membangun fondasi jaringan yang kuat dan aman melalui konfigurasi firewall yang optimal, segmentasi jaringan, serta penerapan protokol komunikasi yang terenkripsi. Ideal untuk organisasi dengan infrastruktur kompleks.",
  },
  {
    icon: <FaUserSecret />,
    title: "Security Awareness Training",
    desc: "70% serangan siber berhasil karena kelalaian manusia. Layanan ini dirancang untuk meningkatkan kesadaran keamanan tim Anda melalui pelatihan simulasi phishing, social engineering, dan best practice penggunaan sistem TI.",
  },
  {
    icon: <FaLaptopCode />,
    title: "Web & Application Security Audit",
    desc: "Audit menyeluruh terhadap aplikasi web dan mobile Anda untuk mengidentifikasi kelemahan terhadap standar OWASP Top 10, SQL Injection, XSS, dan lainnya. Cocok untuk tim pengembang yang ingin memastikan aplikasi aman sebelum dirilis.",
  },
];

const CyberSecurityPage = () => {
  return (
    <section id="services" className="bg-gradient-to-b from-black via-red-900 to-black text-white py-32 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-extrabold mb-6 text-white">
            Layanan CyberSecurity Profesional
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Kami hadir untuk membantu Anda menjaga kepercayaan pelanggan dan kelangsungan bisnis dengan solusi keamanan siber yang menyeluruh, proaktif, dan dapat disesuaikan.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-[#1a1a1a]/80 backdrop-blur-lg border border-neutral-800 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
            >
              <div className="flex justify-center mb-6">
                <div className="w-20 h-20 bg-black/50 border border-neutral-700 rounded-full flex items-center justify-center shadow-xl">
                  <span className="text-red-500 text-3xl">{service.icon}</span>
                </div>
              </div>
              <h3 className="text-2xl font-bold text-center text-white mb-3">
                {service.title}
              </h3>
              <p className="text-sm text-gray-400 text-center leading-relaxed">
                {service.desc}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Closing CTA */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
          className="text-center mt-24"
        >
          <h3 className="text-3xl font-extrabold text-white mb-4">
            Siap Melindungi Aset Digital Anda?
          </h3>
          <p className="text-gray-400 mb-6 max-w-xl mx-auto">
            Hubungi kami hari ini dan dapatkan konsultasi gratis untuk mengidentifikasi kebutuhan keamanan siber Anda secara menyeluruh.
          </p>
          <a
            href="https://wa.me/+6287815969223?text=Halo,%20Saya%20tertarik%20dengan%20layanan%20CyberSecurity%20Anda.%20Bisa%20mendapatkan%20informasi%20lebih%20lanjut?"
            target="_blank"
            className="inline-block px-8 py-4 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-xl shadow-lg transition-all duration-300 transform hover:scale-105"
          >
            Konsultasi Sekarang
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default CyberSecurityPage;
