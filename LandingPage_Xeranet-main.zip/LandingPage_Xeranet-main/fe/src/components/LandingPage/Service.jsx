import { motion } from "framer-motion";
import { FaTools, FaShieldAlt, FaClock } from "react-icons/fa";

const services = [
  {
    title: "Software Development",
    description:
      "Solusi perangkat lunak web dan mobile yang dirancang untuk memenuhi kebutuhan bisnis Anda, meningkatkan performa dan pengalaman pengguna.",
    icon: <FaTools className="text-gold-400 text-4xl" />,
    link: "/SoftwareDevelopment", // Link untuk Software Development
  },
  {
    title: "Cyber Security",
    description:
      "Lindungi data dan sistem Anda dari ancaman digital dengan layanan audit, proteksi, dan monitoring yang dapat diandalkan.",
    icon: <FaShieldAlt className="text-red-500 text-4xl" />,
    link: "/CyberSecurity", // Link untuk Cyber Security
  },
  {
    title: "Networking",
    description:
      "Bangun infrastruktur jaringan yang scalable, aman, dan stabil untuk mendukung operasi bisnis yang lebih efisien.",
    icon: <FaClock className="text-white text-4xl" />,
    link: "/Network", // Link untuk Networking
  },
];

const Services = () => {
  return (
    <section id="services" className="bg-gradient-to-b from-black via-red-900 to-black text-white py-32 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-extrabold mb-6 text-white">
            Layanan Kami
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Di <span className="text-gold-400 font-semibold">Xeranet Solutions Technology</span>, kami menyediakan solusi teknologi yang efektif untuk segala skala bisnis.
          </p>
        </motion.div>

        {/* Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-16">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="bg-[#1a1a1a]/70 backdrop-blur-md border border-neutral-800 rounded-2xl p-8 shadow-lg hover:shadow-red-600/60 transition-all transform hover:scale-[1.05]"
            >
              <a href={service.link} className="block"> {/* Mengarahkan ke link masing-masing */}
                <div className="flex justify-center mb-6">
                  <div className="w-20 h-20 bg-[#1a1a1a]/80 border border-neutral-700 rounded-full flex items-center justify-center shadow-md">
                    {service.icon}
                  </div>
                </div>

                <h3 className="text-2xl font-bold text-center text-white mb-3">
                  {service.title}
                </h3>
                <p className="text-sm text-gray-400 text-center leading-relaxed">
                  {service.description}
                </p>
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
