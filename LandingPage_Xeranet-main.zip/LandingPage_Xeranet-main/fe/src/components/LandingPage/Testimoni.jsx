import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchTestimonials } from "../../app/data/testimoniSlice";
import { motion } from "framer-motion";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";
import { FaQuoteLeft } from "react-icons/fa";
import "swiper/css";
import "swiper/css/autoplay";

const TestimonialCard = ({ t }) => (
  <motion.div
    initial={{ opacity: 0, y: 40 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6 }}
    viewport={{ once: true }}
    className="bg-gradient-to-br from-[#1e1e1e]/80 to-[#000]/80 border border-gray-700/40 backdrop-blur-xl p-8 rounded-3xl shadow-xl hover:shadow-red-500/30 transition duration-300 transform hover:-translate-y-1"
  >
    <FaQuoteLeft className="text-red-500 text-2xl mb-4" />
    <p className="text-gray-300 text-base leading-relaxed italic mb-6">
      “{t.content}”
    </p>
    <div className="flex items-center">
      {/* Cek apakah gambar kosong atau tidak, jika kosong tampilkan gambar fallback */}
      <img
        src={t.testimoniImage ? t.testimoniImage : null} // Jika kosong, set null
        alt={t.author}
        className="w-14 h-14 rounded-full object-cover border-2 border-gray-600"
      />
      <div className="ml-4">
        <h4 className="text-white font-semibold text-lg">{t.author}</h4>
        <p className="text-yellow-400 text-sm">⭐ {t.rating}/5</p>
      </div>
    </div>
  </motion.div>
);

const Testimonial = () => {
  const dispatch = useDispatch();
  const { testimonials = [], isLoading } = useSelector(
    (state) => state.testimonials || {}
  );

  useEffect(() => {
    dispatch(fetchTestimonials());
  }, [dispatch]);

  return (
    <section
      id="testimonials"
      className="w-full bg-gradient-to-b from-black via-gray-900 to-black text-white py-32 px-4"
    >
      <div className="max-w-6xl mx-auto">
        {/* Heading */}
        <div className="text-center mb-20">
          <motion.h2
            initial={{ opacity: 0, y: -40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-5xl font-extrabold mb-4 tracking-tight text-white"
          >
            Apa Kata Klien Kami
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-gray-400 text-lg max-w-2xl mx-auto"
          >
            Kami bangga mendapatkan kepercayaan dari berbagai klien. Ini cerita mereka.
          </motion.p>
        </div>

        {/* Testimonial Content */}
        {isLoading ? (
          <p className="text-center text-gray-400">Loading testimonial...</p>
        ) : testimonials.length === 0 ? (
          <p className="text-center text-gray-500">Belum ada testimonial.</p>
        ) : testimonials.length > 3 ? (
          <Swiper
            modules={[Autoplay]}
            loop={true}
            autoplay={{ delay: 5000, disableOnInteraction: false }}
            spaceBetween={30}
            breakpoints={{
              640: { slidesPerView: 1 },
              768: { slidesPerView: 2 },
              1024: { slidesPerView: 3 },
            }}
            className="w-full"
          >
            {testimonials.map((t, index) => (
              <SwiperSlide key={index}>
                <TestimonialCard t={t} />
              </SwiperSlide>
            ))}
          </Swiper>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
            {testimonials.map((t, index) => (
              <TestimonialCard key={index} t={t} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default Testimonial;
