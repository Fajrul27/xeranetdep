import React, { useState, useEffect } from "react";

const WhatsAppButton = () => {
  const phoneNumber = "6287815969223"; 
  const message = encodeURIComponent("Halo, saya ingin mendapatkan informasi lebih lanjut tentang layanan di Xeranet. Bisakah kita diskusi lebih lanjut?");
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setShowPopup(true);
      setTimeout(() => {
        setShowPopup(false);
      }, 3000); // Popup muncul selama 3 detik
    }, 30000); // Muncul setiap 30 detik

    return () => clearInterval(interval);
  }, []);

  return (
    <div style={styles.container}>
      {/* Popup Chat WhatsApp */}
      {showPopup && (
        <div style={styles.popup} className="fade-in">
          <div style={styles.chatHeader}>
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"
              alt="WA"
              style={styles.profilePic}
            />
            <span style={styles.chatTitle}>Customer Support</span>
          </div>
          <div style={styles.chatBody}>
            <p>Hai! 👋 Butuh bantuan? Chat kami di WhatsApp!</p>
          </div>
        </div>
      )}

      {/* Tombol WhatsApp */}
      <a
        href={`https://wa.me/${phoneNumber}?text=${message}`}
        target="_blank"
        rel="noopener noreferrer"
        style={styles.whatsappButton}
        className="bounce"
      >
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"
          alt="WhatsApp"
          style={styles.icon}
        />
      </a>

      {/* Animasi */}
      <style>
        {`
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .fade-in {
            animation: fadeIn 0.5s ease-in-out;
          }

          @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
          }
          .bounce {
            animation: bounce 1s infinite ease-in-out;
          }
        `}
      </style>
    </div>
  );
};

const styles = {
  container: {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
    zIndex: 9999,
  },
  popup: {
    backgroundColor: "#ECE5DD", // Warna seperti chat WhatsApp
    padding: "10px",
    borderRadius: "10px",
    fontSize: "14px",
    marginBottom: "10px",
    width: "250px",
    boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
  },
  chatHeader: {
    display: "flex",
    alignItems: "center",
    borderBottom: "1px solid #ddd",
    paddingBottom: "5px",
    marginBottom: "5px",
  },
  profilePic: {
    width: "25px",
    height: "25px",
    borderRadius: "50%",
    marginRight: "10px",
  },
  chatTitle: {
    fontWeight: "bold",
    fontSize: "14px",
  },
  chatBody: {
    fontSize: "13px",
    color: "#333",
  },
  whatsappButton: {
    backgroundColor: "#25D366",
    borderRadius: "50%",
    width: "60px",
    height: "60px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
    cursor: "pointer",
  },
  icon: {
    width: "35px",
    height: "35px",
  },
};

export default WhatsAppButton;
