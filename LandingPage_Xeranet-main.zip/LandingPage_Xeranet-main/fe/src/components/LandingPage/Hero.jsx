/* eslint-disable no-unused-vars */
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchHeroes } from "../../app/data/heroSlice";

const Hero = () => {
  const { heroes } = useSelector((state) => state.hero);
  const dispatch = useDispatch();
  const [mediaSrc, setMediaSrc] = useState("/BG.mp4");
  const [isVideo, setIsVideo] = useState(true);

  const waNumber = import.meta.env.VITE_WaNumber;

  useEffect(() => {
    dispatch(fetchHeroes());
  }, [dispatch]);

  useEffect(() => {
    const activeHero = heroes.find((hero) => hero.isActive === true);

    if (activeHero?.heroImage) {
      const url = activeHero.heroImage;
      const extension = url.split(".").pop().toLowerCase();

      const videoFormats = ["mp4", "webm", "ogg"];
      const imageFormats = ["jpg", "jpeg", "png", "gif", "webp"];

      if (videoFormats.includes(extension)) {
        setMediaSrc(url);
        setIsVideo(true);
      } else if (imageFormats.includes(extension)) {
        setMediaSrc(url);
        setIsVideo(false);
      } else {
        setMediaSrc("/BG.mp4");
        setIsVideo(true);
      }
    } else {
      setMediaSrc("/BG.mp4");
      setIsVideo(true);
    }
  }, [heroes]);

  return (
    <section id="hero" className="relative w-full h-screen overflow-hidden">
      {/* Background Media */}
      <div className="absolute inset-0 z-0">
        <div className="w-full h-full absolute bg-black opacity-40"></div> {/* Overlay for dimming */}
        {isVideo ? (
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover scale-110 filter brightness-40 contrast-100"
          >
            <source src={mediaSrc} type="video/mp4" />
          </video>
        ) : (
          <img
            src={mediaSrc}
            alt="Hero Background"
            className="w-full h-full object-cover scale-110 filter brightness-40 contrast-100"
            loading="lazy"
          />
        )}
      </div>

      {/* Hero Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center text-white px-8">
  <motion.h1
    initial={{ opacity: 0, y: -40 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.8, delay: 0.3 }}
    className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 text-gold-500 leading-tight"
  >
    Xeranet Solutions Technology
  </motion.h1>
{/* 
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-lg md:text-xl lg:text-2xl max-w-3xl mb-6 leading-relaxed"
        >
          Solusi Terintegrasi untuk Pengembangan Web & Mobile | Keamanan Siber yang Tangguh | Jaringan Perusahaan yang Handal
        </motion.p> */}

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="text-base md:text-lg max-w-2xl mb-8 text-gray-300 leading-relaxed"
        >
          Kami menghadirkan solusi digital yang memungkinkan Anda untuk berkembang lebih cepat, dengan fokus pada keamanan dan efisiensi operasional.
        </motion.p>

        <div className="flex flex-col sm:flex-row gap-6 mt-8">
          <motion.a
            href={`https://wa.me/${waNumber}?text=${encodeURIComponent("Konsultasi Gratis")}`}
            target="_blank"
            rel="noopener noreferrer"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-8 rounded-lg transition duration-300 text-center shadow-lg"
          >
            Kontak Kami
          </motion.a>

          <motion.a
            href="/service"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.9 }}
            className="border border-white text-white font-semibold py-3 px-8 rounded-lg hover:bg-white hover:text-black transition duration-300 text-center shadow-lg"
          >
            Layanan Kami
          </motion.a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
