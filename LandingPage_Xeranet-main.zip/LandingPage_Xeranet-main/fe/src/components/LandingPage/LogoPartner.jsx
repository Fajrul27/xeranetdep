import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";
import "swiper/css";
import "swiper/css/autoplay";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { fetchLogoPTs } from "../../app/data/logoPTSlice";

const LogoPartner = () => {
  const { logoPTs } = useSelector((state) => state.logoPTs);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchLogoPTs());
  }, [dispatch]);

  return (
    <section className="py-16 bg-black">
      <h2 className="text-center text-3xl font-extrabold text-white mb-12 md:mb-16 lg:mb-30 tracking-tight">
       Mitra Kami
      </h2>
      <Swiper
        modules={[Autoplay]}
        spaceBetween={40}
        slidesPerView={4}
        autoplay={{
          delay: 2000,
          disableOnInteraction: false,
        }}
        loop={true}
        breakpoints={{
          640: {
            slidesPerView: 2,
            spaceBetween: 20,
          },
          768: {
            slidesPerView: 3,
            spaceBetween: 30,
          },
          1024: {
            slidesPerView: 4,
            spaceBetween: 40,
          },
        }}
        className="w-full max-w-6xl mx-auto"
      >
        {logoPTs.map((logo, index) => (
          <SwiperSlide
            key={index}
            className="flex justify-center items-center bg-transparent transition-all transform hover:scale-110 hover:opacity-80"
          >
            <img
              src={logo.logoPTImage}
              alt={`Logo ${index + 1}`}
              className="h-16 object-contain transition-transform duration-500 ease-in-out"
            />
          </SwiperSlide>
        ))}
      </Swiper>
    </section>
  );
};

export default LogoPartner;
