import { Route, Routes, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Hero from "./components/LandingPage/Hero";
import Cyber from "./components/LandingPage/cyber";
import Network from "./components/LandingPage/network";
import Software from "./components/LandingPage/software";
import Service from "./components/LandingPage/Service";
import Testimoni from "./components/LandingPage/Testimoni";
import LogoPartner from "./components/LandingPage/LogoPartner";
import IklanPopUp from "./components/LandingPage/IklanPopUp";
import Hero2 from "./components/LandingPage/Hero2";
import About from "./pages/LandingPage/About";
import Blog from "./pages/LandingPage/blog/Blog";
import BlogDetail from "./pages/LandingPage/blog/BlogDetail";
import ServicePage from "./pages/LandingPage/service/ServicePage";
import NotFound from "./components/LandingPage/notfound";
import LandingPageLayout from "./Layout/LandingPageLayout";

function ScrollToTop() {
  const location = useLocation();

  useEffect(() => {
    if (location.pathname === "" && location.hash === "#service") {
      const element = document.getElementById("service");
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  }, [location]);
}

function App() {
  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route
          path="/"
          element={
            <LandingPageLayout>
              <Hero />
              <Service />
              <LogoPartner />
              <Hero2 />
              <Testimoni />
              <IklanPopUp />
            </LandingPageLayout>
          }
        />
        <Route path="/CyberSecurity" element={<LandingPageLayout><Cyber /></LandingPageLayout>} />
        <Route path="/SoftwareDevelopment" element={<LandingPageLayout><Software /></LandingPageLayout>} />
        <Route path="/Network" element={<LandingPageLayout><Network /></LandingPageLayout>} />
        <Route path="/about" element={<LandingPageLayout><About /></LandingPageLayout>} />
        <Route path="/service" element={<LandingPageLayout><ServicePage /></LandingPageLayout>} />
        <Route path="/blog" element={<LandingPageLayout><Blog /></LandingPageLayout>} />
        <Route path="/blog/:id" element={<LandingPageLayout><BlogDetail /></LandingPageLayout>} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}

export default App;
