/* eslint-disable no-unused-vars */
import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { useDispatch, useSelector } from "react-redux";
import { fetchBlogs } from "../../../app/data/blogSlice.js";

const Blog = () => {
  const { blogs, isLoading } = useSelector((state) => state.blog);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchBlogs());
  }, [dispatch]);

  return (
    <section
      className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#111] to-[#0b0b0b] text-white py-20 px-6"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.h1
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-5xl font-extrabold text-center text-white mb-6"
        >
          Blog & Artikel
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-gray-400 text-lg md:text-xl text-center mb-16 max-w-3xl mx-auto"
        >
          Temukan berbagai artikel seputar teknologi, bisnis, desain, dan
          produktivitas untuk menginspirasi perjalanan digitalmu.
        </motion.p>

        {/* Blog Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">
          {blogs
            .filter((post) => post.status === "publish")
            .map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.3 }}
                className="bg-[#2b2b2b] rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl hover:scale-105 transition-transform duration-300"
              >
                {/* Wrap entire card in Link to make image and content clickable */}
                <Link to={`/blog/${post._id}`} state={{ blog: post }} className="block">
                  {/* Blog Image */}
                  <img
                    src={post.blogImage}
                    alt={post.title}
                    className="w-full h-60 object-cover rounded-t-3xl"
                  />
                  <div className="p-6">
                    {/* Blog Content */}
                    <p className="text-sm text-gray-500 mb-2">{post.createdAt}</p>
                    <h2 className="text-2xl font-semibold text-white mb-3">{post.title}</h2>
                    <p className="text-gray-300 text-sm mb-4">
                      {post.content.slice(0, 120)}...
                    </p>
                    {/* Link to full post */}
                    <span className="text-sm text-blue-400 hover:underline">
                      Baca Selengkapnya →
                    </span>
                  </div>
                </Link>
              </motion.div>
            ))}
        </div>
      </div>
    </section>
  );
};

export default Blog;
