/* eslint-disable no-unused-vars */
import { motion } from "framer-motion";

const About = () => {
  return (
    <section className="w-full bg-gradient-to-b from-[#1a0000] via-[#0d0d0d] to-black text-white py-20 px-6 md:px-10">
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-6xl mx-auto"
      >
        <div className="mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-left text-red-500 mb-4 drop-shadow-md">
            Tentang Xeranet
          </h2>
          <p className="text-gray-300 text-lg md:text-xl max-w-4xl leading-relaxed">
            Xeranet Solutions Technology adalah perusahaan teknologi yang berfokus pada transformasi digital
            melalui solusi inovatif di bidang pengembangan perangkat lunak, keamanan siber, dan infrastruktur jaringan.
            Kami hadir untuk membantu bisnis membangun fondasi digital yang kokoh dan berkelanjutan.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* VISI */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="bg-[#1a1a1a] p-6 rounded-2xl shadow-lg border border-[#2a2a2a] hover:shadow-red-600 transition-shadow"
          >
            <h3 className="text-2xl font-semibold mb-3 text-white">Visi Kami</h3>
            <p className="text-gray-300 text-sm md:text-base leading-relaxed">
              Menjadi mitra strategis utama dalam perjalanan digitalisasi bisnis, dengan menyediakan solusi teknologi
              yang relevan, aman, dan berdampak nyata pada pertumbuhan jangka panjang.
            </p>
          </motion.div>

          {/* MISI */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="bg-[#1a1a1a] p-6 rounded-2xl shadow-lg border border-[#2a2a2a] hover:shadow-red-600 transition-shadow"
          >
            <h3 className="text-2xl font-semibold mb-3 text-white">Misi Kami</h3>
            <ul className="list-disc list-inside text-gray-300 text-sm md:text-base space-y-2">
              <li>Mengembangkan solusi teknologi yang handal dan berdaya guna.</li>
              <li>Memberikan layanan yang adaptif dan berorientasi pada kebutuhan bisnis.</li>
              <li>Mendorong efisiensi operasional melalui automasi dan sistem cerdas.</li>
              <li>Menjaga standar keamanan dan kualitas sebagai prioritas utama.</li>
            </ul>
          </motion.div>

          {/* NILAI */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="bg-[#1a1a1a] p-6 rounded-2xl shadow-lg border border-[#2a2a2a] hover:shadow-red-600 transition-shadow"
          >
            <h3 className="text-2xl font-semibold mb-3 text-white">Nilai Inti</h3>
            <ul className="list-disc list-inside text-gray-300 text-sm md:text-base space-y-2">
              <li><strong>Integritas:</strong> Menjaga kepercayaan melalui transparansi dan etika kerja.</li>
              <li><strong>Inovasi:</strong> Beradaptasi dengan teknologi terbaru untuk solusi berkelanjutan.</li>
              <li><strong>Kolaborasi:</strong> Kemitraan erat untuk hasil maksimal.</li>
              <li><strong>Komitmen:</strong> Dedikasi tinggi terhadap kepuasan klien.</li>
              <li><strong>Keamanan:</strong> Menjamin proteksi penuh dalam setiap solusi yang kami hadirkan.</li>
            </ul>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};

export default About;
