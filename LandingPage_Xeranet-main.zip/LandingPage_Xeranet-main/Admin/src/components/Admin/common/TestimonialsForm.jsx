import { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { getMe, updateProfile } from "../../../app/users/authSlice";
import { motion } from "framer-motion";
import { FaRegTimesCircle } from "react-icons/fa";

const EditProfileForm = ({ open, onClose, profile }) => {
  const [form, setForm] = useState({
    fullName: "",
    userName: "",
    email: "",
    oldPassword: "",
    newPassword: "",
  });
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const dispatch = useDispatch();

  useEffect(() => {
    if (profile) {
      setForm({
        fullName: profile.fullName || "",
        userName: profile.userName || "",
        email: profile.email || "",
        oldPassword: "",
        newPassword: "",
      });
    }
  }, [profile]);

  useEffect(() => {
    if (!open) {
      setForm({
        fullName: "",
        userName: "",
        email: "",
        oldPassword: "",
        newPassword: "",
      });
      setImage(null);
      setMessage("");
    }
  }, [open]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    setImage(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    const formData = new FormData();
    formData.append("fullName", form.fullName);
    formData.append("userName", form.userName);
    formData.append("email", form.email);
    if (form.oldPassword && form.newPassword) {
      formData.append("oldPassword", form.oldPassword);
      formData.append("newPassword", form.newPassword);
    }
    if (image) {
      formData.append("image", image);
    }

    try {
      await dispatch(updateProfile(formData)).unwrap();
      await dispatch(getMe()).unwrap();
      setMessage("Profil berhasil diperbarui");
      onClose();
    } catch (err) {
      console.error(err);
      setMessage(err?.response?.data?.message || "Gagal memperbarui profil");
    } finally {
      setLoading(false);
    }
  };

  return (
    <dialog className={`modal ${open ? "modal-open" : ""}`}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0 }}
        className="modal-box max-w-2xl w-full"
      >
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="flex justify-between items-center mb-1">
            <h3 className="text-xl font-bold">Edit Profil</h3>
            <button
              type="button"
              onClick={onClose}
              className="text-gray-500 hover:text-red-500 text-lg cursor-pointer"
            >
              <FaRegTimesCircle />
            </button>
          </div>

          {message && (
            <div className="text-sm text-error text-center">{message}</div>
          )}

          <div className="grid gap-4">
            <input
              type="text"
              name="fullName"
              placeholder="Nama Lengkap"
              className="input input-bordered w-full"
              value={form.fullName}
              onChange={handleChange}
            />
            <input
              type="text"
              name="userName"
              placeholder="Username"
              className="input input-bordered w-full"
              value={form.userName}
              onChange={handleChange}
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              className="input input-bordered w-full"
              value={form.email}
              onChange={handleChange}
            />

            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="file-input file-input-bordered w-full"
            />

            <hr className="my-1" />

            <input
              type="password"
              name="oldPassword"
              placeholder="Password Lama"
              className="input input-bordered w-full"
              value={form.oldPassword}
              onChange={handleChange}
            />
            <input
              type="password"
              name="newPassword"
              placeholder="Password Baru"
              className="input input-bordered w-full"
              value={form.newPassword}
              onChange={handleChange}
            />
          </div>

          <div className="modal-action justify-between">
            <button type="button" onClick={onClose} className="btn btn-ghost">
              Batal
            </button>
            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading}
            >
              {loading ? "Menyimpan..." : "Simpan"}
            </button>
          </div>
        </form>
      </motion.div>
    </dialog>
  );
};

export default EditProfileForm;
