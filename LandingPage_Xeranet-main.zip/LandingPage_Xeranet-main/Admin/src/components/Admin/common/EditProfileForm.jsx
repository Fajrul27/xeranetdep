import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { FaRegTimesCircle } from "react-icons/fa";
import { useDispatch } from "react-redux";
import { getMe, updateProfile } from "../../../app/users/authSlice";

const EditProfileForm = ({ open, onClose, profile }) => {
  const [form, setForm] = useState({
    fullName: "",
    userName: "",
    email: "",
    oldPassword: "",
    newPassword: "",
  });
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const fileInputRef = useRef(null);
  const dispatch = useDispatch();

  useEffect(() => {
    if (profile) {
      setForm({
        fullName: profile.fullName || "",
        userName: profile.userName || "",
        email: profile.email || "",
        oldPassword: "",
        newPassword: "",
      });
    }
  }, [profile]);

  useEffect(() => {
    if (!open) {
      setForm({
        fullName: "",
        userName: "",
        email: "",
        oldPassword: "",
        newPassword: "",
      });
      setImage(null);
      setMessage("");
    }
  }, [open]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    setImage(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    const formData = new FormData();
    formData.append("fullName", form.fullName);
    formData.append("userName", form.userName);
    formData.append("email", form.email);
    if (form.oldPassword && form.newPassword) {
      formData.append("oldPassword", form.oldPassword);
      formData.append("newPassword", form.newPassword);
    }
    if (image) {
      formData.append("image", image);
    }

    try {
      await dispatch(updateProfile(formData)).unwrap();
      await dispatch(getMe()).unwrap();
      setMessage("Profil berhasil diperbarui");
      onClose();
    } catch (err) {
      console.error(err);
      setMessage(
        err?.response?.data?.message || "Gagal memperbarui profil, coba lagi."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <dialog className={`modal ${open ? "modal-open" : ""}`}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0 }}
        className="modal-box max-w-2xl w-full"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-xl font-semibold">Edit Profil</h3>
            <button
              type="button"
              onClick={onClose}
              className="text-gray-500 hover:text-red-500 text-lg"
            >
              <FaRegTimesCircle />
            </button>
          </div>

          {message && (
            <p className="text-sm text-center text-error">{message}</p>
          )}

          <div>
            <label className="label">
              <span className="label-text">Nama Lengkap</span>
            </label>
            <input
              type="text"
              name="fullName"
              value={form.fullName}
              onChange={handleChange}
              className="input input-bordered w-full"
              placeholder="Nama Lengkap"
              required
            />
          </div>

          <div>
            <label className="label">
              <span className="label-text">Username</span>
            </label>
            <input
              type="text"
              name="userName"
              value={form.userName}
              onChange={handleChange}
              className="input input-bordered w-full"
              placeholder="Username"
              required
            />
          </div>

          <div>
            <label className="label">
              <span className="label-text">Email</span>
            </label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              className="input input-bordered w-full"
              placeholder="Email"
              required
            />
          </div>

          <div>
            <label className="label">
              <span className="label-text">Foto Profil (opsional)</span>
            </label>
            <input
              type="file"
              accept="image/*"
              ref={fileInputRef}
              className="file-input file-input-bordered w-full"
              onChange={handleFileChange}
            />
            {image && (
              <p className="text-sm mt-1 text-green-600">
                File dipilih: {image.name}
              </p>
            )}
          </div>

          <div className="divider my-2" />

          <div>
            <label className="label">
              <span className="label-text">Password Lama</span>
            </label>
            <input
              type="password"
              name="oldPassword"
              value={form.oldPassword}
              onChange={handleChange}
              className="input input-bordered w-full"
              placeholder="Password Lama"
            />
          </div>

          <div>
            <label className="label">
              <span className="label-text">Password Baru</span>
            </label>
            <input
              type="password"
              name="newPassword"
              value={form.newPassword}
              onChange={handleChange}
              className="input input-bordered w-full"
              placeholder="Password Baru"
            />
          </div>

          <div className="modal-action justify-between">
            <button type="button" onClick={onClose} className="btn btn-ghost">
              Batal
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? "Menyimpan..." : "Simpan"}
            </button>
          </div>
        </form>
      </motion.div>
    </dialog>
  );
};

export default EditProfileForm;
