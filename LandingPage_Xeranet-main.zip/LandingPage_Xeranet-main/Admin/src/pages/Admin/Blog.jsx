import { useEffect, useState } from "react";
import { FaEdit, FaTrash } from "react-icons/fa";
import { useDispatch, useSelector } from "react-redux";
import {
  deleteExistingBlog,
  fetchBlogs,
  updateExistingBlog,
} from "../../app/data/blogSlice";
import BlogForm from "../../components/Admin/common/BlogForm";
import Toast from "../../components/Admin/common/Toast";
import ConfirmDeleteModal from "../../components/Admin/common/ConfirmDeleteModal";

const Blog = () => {
  const [openForm, setOpenForm] = useState(false);
  const [selectedBlog, setSelectedBlog] = useState(null);
  const [toast, setToast] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [blogToDelete, setBlogToDelete] = useState(null); // Untuk menyimpan blog yang akan dihapus
  const [currentPage, setCurrentPage] = useState(1);
  const blogsPerPage = 5;

  const { blogs, isLoading } = useSelector((state) => state.blog);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchBlogs());
  }, [dispatch]);

  const handleCreate = () => {
    setSelectedBlog(null);
    setOpenForm(true);
  };

  const handleEdit = (blog) => {
    setSelectedBlog(blog);
    setOpenForm(true);
  };

  const handleDelete = (blog) => {
    setBlogToDelete(blog);
    setIsDeleteModalOpen(true); // Menampilkan modal konfirmasi
  };

  const confirmDelete = async () => {
    if (blogToDelete) {
      try {
        await dispatch(deleteExistingBlog(blogToDelete._id)).unwrap();
        setToast({ type: "success", message: "Blog berhasil dihapus" });
        dispatch(fetchBlogs());
      } catch (error) {
        setToast({ type: "error", message: "Gagal menghapus blog" });
      }
    }
    setIsDeleteModalOpen(false); // Menutup modal setelah konfirmasi
    setBlogToDelete(null); // Reset blog yang akan dihapus
  };

  const cancelDelete = () => {
    setIsDeleteModalOpen(false); // Menutup modal jika dibatalkan
    setBlogToDelete(null); // Reset blog yang akan dihapus
  };

  const handleToggleStatus = async (blog) => {
    const newStatus = blog.status === "published" ? "draft" : "published";
    try {
      await dispatch(
        updateExistingBlog({
          id: blog._id,
          FormData: {
            title: blog.title,
            content: blog.content,
            status: newStatus,
          },
        })
      ).unwrap();
      setToast({ type: "success", message: "Status blog diperbarui" });
      dispatch(fetchBlogs());
    } catch (error) {
      setToast({ type: "error", message: "Gagal memperbarui status" });
    }
  };

  // Pagination logic
  const indexOfLastBlog = currentPage * blogsPerPage;
  const indexOfFirstBlog = indexOfLastBlog - blogsPerPage;
  const currentBlogs = blogs.slice(indexOfFirstBlog, indexOfLastBlog);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  if (isLoading) return <div className="text-center py-10">Loading...</div>;

  return (
    <div className="p-6 md:p-10 space-y-6">
      {toast && <Toast {...toast} onClose={() => setToast(null)} />}

      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-800 dark:text-white">
          Kelola Blog
        </h1>
        <button
          onClick={handleCreate}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow text-sm md:text-base transition"
        >
          Tambah Blog
        </button>
      </div>

      {/* Table */}
      <div className="overflow-x-auto bg-white dark:bg-gray-800 rounded-lg shadow">
        <table className="min-w-full table-auto text-sm md:text-base">
          <thead className="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-white">
            <tr>
              <th className="px-6 py-3 text-left">Judul</th>
              <th className="px-6 py-3 text-left">Tanggal</th>
              <th className="px-6 py-3 text-left">Status</th>
              <th className="px-6 py-3 text-left">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {currentBlogs?.map((blog) => (
              <tr
                key={blog._id}
                className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition"
              >
                <td className="px-6 py-4 font-medium text-gray-800 dark:text-white">
                  {blog.title}
                </td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-300">
                  {new Date(blog.createdAt).toLocaleDateString()}
                </td>
                <td className="px-6 py-4">
                  <button
                    onClick={() => handleToggleStatus(blog)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide ${
                      blog.status === "published"
                        ? "bg-green-500 text-white"
                        : "bg-yellow-400 text-black"
                    }`}
                  >
                    {blog.status}
                  </button>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-wrap gap-2 justify-center">
                    <button
                      onClick={() => handleEdit(blog)}
                      className="flex items-center gap-1 px-3 py-1 border border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white rounded-md text-xs transition"
                    >
                      <FaEdit /> Edit
                    </button>
                    <button
                      onClick={() => handleDelete(blog)}
                      className="flex items-center gap-1 px-3 py-1 border border-red-500 text-red-500 hover:bg-red-500 hover:text-white rounded-md text-xs transition"
                    >
                      <FaTrash /> Hapus
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {blogs.length > blogsPerPage && (
        <div className="flex justify-center mt-4">
          <button
            onClick={() => paginate(currentPage - 1)}
            disabled={currentPage === 1}
            className="px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-md disabled:bg-gray-300 transition"
          >
            Previous
          </button>
          <span className="mx-4 text-sm text-gray-700 dark:text-white">
            Page {currentPage}
          </span>
          <button
            onClick={() => paginate(currentPage + 1)}
            disabled={currentPage * blogsPerPage >= blogs.length}
            className="px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-md disabled:bg-gray-300 transition"
          >
            Next
          </button>
        </div>
      )}

      {/* Blog Form Modal */}
      <BlogForm
        open={openForm}
        onClose={() => setOpenForm(false)}
        blog={selectedBlog}
        setToast={setToast}
      />

      {/* Modal Konfirmasi Penghapusan */}
      <ConfirmDeleteModal
        isOpen={isDeleteModalOpen}
        onCancel={cancelDelete}
        onConfirm={confirmDelete}
        blogTitle={blogToDelete?.title}
      />
    </div>
  );
};

export default Blog;
