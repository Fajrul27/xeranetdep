// import { useEffect, useState } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { fetchUsers, addUser } from '../../app/users/userSlice'; // Mengimpor aksi Redux
// import { useNavigate } from 'react-router-dom';

// const AddUser = () => {
//   const [name, setName] = useState('');
//   const [email, setEmail] = useState('');
//   const [role, setRole] = useState('user');
//   const [password, setPassword] = useState('');
//   const [confirmPassword, setConfirmPassword] = useState('');
//   const [error, setError] = useState('');

//   const dispatch = useDispatch();
//   const navigate = useNavigate();

//   const { users, loading, error: usersError } = useSelector((state) => state.users); // Ambil data users dari Redux

//   useEffect(() => {
//     dispatch(fetchUsers()); // Ambil data user saat komponen dimuat
//   }, [dispatch]);

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (password !== confirmPassword) {
//       setError('Passwords do not match!');
//       return;
//     }

//     const newUser = { name, email, role, password };

//     try {
//       await dispatch(addUser(newUser)); // Kirim data user baru ke Redux
//       navigate('/admin/manage-users'); // Redirect setelah sukses
//     } catch (err) {
//       setError('Failed to add user.');
//     }
//   };

//   if (loading) {
//     return <p>Loading...</p>;
//   }

//   if (usersError) {
//     return <p>Error loading users: {usersError}</p>;
//   }

//   return (
//     <div className="max-w-4xl mx-auto p-6 bg-white shadow-md rounded-lg">
//       <h2 className="text-2xl font-semibold mb-4">Add New User</h2>

//       {error && <div className="text-red-500 mb-4">{error}</div>}

//       {/* Form Add User */}
//       <form onSubmit={handleSubmit} className="space-y-4">
//         <div>
//           <label htmlFor="name" className="block text-sm font-medium">Name</label>
//           <input
//             type="text"
//             id="name"
//             value={name}
//             onChange={(e) => setName(e.target.value)}
//             className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-md"
//             required
//           />
//         </div>
//         <div>
//           <label htmlFor="email" className="block text-sm font-medium">Email</label>
//           <input
//             type="email"
//             id="email"
//             value={email}
//             onChange={(e) => setEmail(e.target.value)}
//             className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-md"
//             required
//           />
//         </div>
//         <div>
//           <label htmlFor="role" className="block text-sm font-medium">Role</label>
//           <select
//             id="role"
//             value={role}
//             onChange={(e) => setRole(e.target.value)}
//             className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-md"
//           >
//             <option value="user">User</option>
//             <option value="admin">Admin</option>
//           </select>
//         </div>
//         <div>
//           <label htmlFor="password" className="block text-sm font-medium">Password</label>
//           <input
//             type="password"
//             id="password"
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//             className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-md"
//             required
//           />
//         </div>
//         <div>
//           <label htmlFor="confirmPassword" className="block text-sm font-medium">Confirm Password</label>
//           <input
//             type="password"
//             id="confirmPassword"
//             value={confirmPassword}
//             onChange={(e) => setConfirmPassword(e.target.value)}
//             className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-md"
//             required
//           />
//         </div>
//         <button
//           type="submit"
//           className="w-full py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 mt-4"
//         >
//           Add User
//         </button>
//       </form>

//       {/* Daftar Pengguna */}
//       <div className="mt-8">
//         <h3 className="text-xl font-semibold">Existing Users</h3>
//         <ul>
//           {users.map((user) => (
//             <li key={user.id}>{user.name} - {user.email}</li> // Menampilkan nama dan email user
//           ))}
//         </ul>
//       </div>
//     </div>
//   );
// };

// export default AddUser;


const AddUser = () => {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center p-8 bg-white shadow-md rounded-lg max-w-md">
          <h1 className="text-2xl font-semibold text-gray-800 mb-4">
            Halaman Belum Tersedia
          </h1>
          <p className="text-gray-600">
            Halaman ini masih dalam proses pengembangan. Silakan kembali lagi nanti.
          </p>
        </div>
      </div>
    );
  };
  
  export default AddUser;
  