import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchTestimonials,
  removeTestimonial,
} from "../../app/data/testimoniSlice";
import TestimonialForm from "../../components/Admin/common/TestimonialsForm";
import ConfirmDeleteModal from "../../components/Admin/common/ConfirmDeleteModal";

const Testimonials = () => {
  const [openForm, setOpenForm] = useState(false);
  const [selectedTestimonial, setSelectedTestimonial] = useState(null);
  const [toast, setToast] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [testimonialToDelete, setTestimonialToDelete] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const testimonialsPerPage = 5;

  const dispatch = useDispatch();
  const { testimonials = [], isLoading, error } = useSelector(
    (state) => state.testimonials || {}
  );

  useEffect(() => {
    dispatch(fetchTestimonials());
  }, [dispatch]);

  const handleEdit = (testimonial) => {
    setSelectedTestimonial(testimonial);
    setOpenForm(true);
  };

  const handleDelete = (testimonial) => {
    setTestimonialToDelete(testimonial);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = async () => {
    if (testimonialToDelete) {
      try {
        await dispatch(removeTestimonial(testimonialToDelete._id)).unwrap();
        setToast({ type: "success", message: "Testimonial berhasil dihapus" });
        dispatch(fetchTestimonials());
      } catch (error) {
        setToast({
          type: "error",
          message: "Gagal menghapus testimonial",
          error: error.message,
        });
      } finally {
        setIsDeleteModalOpen(false);
        setTestimonialToDelete(null);
      }
    }
  };

  const cancelDelete = () => {
    setIsDeleteModalOpen(false);
    setTestimonialToDelete(null);
  };

  // Pagination logic
  const indexOfLastTestimonial = currentPage * testimonialsPerPage;
  const indexOfFirstTestimonial = indexOfLastTestimonial - testimonialsPerPage;
  const currentTestimonials = testimonials.slice(
    indexOfFirstTestimonial,
    indexOfLastTestimonial
  );

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div className="p-6 md:p-10 space-y-6">
      {toast && (
        <div
          className={`px-4 py-2 rounded shadow text-sm max-w-sm mx-auto ${
            toast.type === "success"
              ? "bg-green-100 text-green-800"
              : "bg-red-100 text-red-800"
          }`}
        >
          {toast.message}
        </div>
      )}

      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-800 dark:text-white">
          Daftar Testimonial
        </h1>
        <button
          onClick={() => {
            setSelectedTestimonial(null);
            setOpenForm(true);
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg shadow-md transition"
        >
          + Tambah Testimonial
        </button>
      </div>

      {/* Table */}
      <div className="overflow-x-auto bg-white dark:bg-gray-800 rounded-lg shadow">
        {testimonials.length === 0 ? (
          <div className="text-center text-gray-600 dark:text-gray-300 py-10">
            Tidak ada testimonial untuk ditampilkan.
          </div>
        ) : (
          <table className="min-w-full table-auto text-sm md:text-base">
            <thead className="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-white">
              <tr>
                <th className="px-6 py-3 text-left">Nama</th>
                <th className="px-6 py-3 text-left">Posisi</th>
                <th className="px-6 py-3 text-left">Rating</th>
                <th className="px-6 py-3 text-left">Konten</th>
                <th className="px-6 py-3 text-left">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {currentTestimonials.map((testimonial) => (
                <tr
                  key={testimonial._id || testimonial.id}
                  className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition"
                >
                  <td className="px-6 py-4 font-medium text-gray-800 dark:text-white">
                    {testimonial.name}
                  </td>
                  <td className="px-6 py-4 text-gray-600 dark:text-gray-300">
                    {testimonial.position}
                  </td>
                  <td className="px-6 py-4 text-gray-600 dark:text-gray-300">
                    {testimonial.rating}/5
                  </td>
                  <td className="px-6 py-4 text-gray-600 dark:text-gray-300">
                    "{testimonial.content}"
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleEdit(testimonial)}
                        className="px-3 py-1 text-sm border border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white rounded-md transition"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(testimonial)}
                        className="px-3 py-1 text-sm border border-red-500 text-red-500 hover:bg-red-500 hover:text-white rounded-md transition"
                      >
                        Hapus
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Pagination */}
      {testimonials.length > testimonialsPerPage && (
        <div className="flex justify-center mt-4">
          <button
            onClick={() => paginate(currentPage - 1)}
            disabled={currentPage === 1}
            className="px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-md disabled:bg-gray-300 transition"
          >
            Previous
          </button>
          <span className="mx-4 text-sm text-gray-700 dark:text-white">
            Page {currentPage}
          </span>
          <button
            onClick={() => paginate(currentPage + 1)}
            disabled={currentPage * testimonialsPerPage >= testimonials.length}
            className="px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-md disabled:bg-gray-300 transition"
          >
            Next
          </button>
        </div>
      )}

      {/* Testimonial Form Modal */}
      <TestimonialForm
        open={openForm}
        onClose={() => setOpenForm(false)}
        setToast={setToast}
        testimonial={selectedTestimonial}
      />

      {/* Confirm Delete Modal */}
      <ConfirmDeleteModal
        isOpen={isDeleteModalOpen}
        onCancel={cancelDelete}
        onConfirm={confirmDelete}
        testimonialName={testimonialToDelete?.name}
      />
    </div>
  );
};

export default Testimonials;
